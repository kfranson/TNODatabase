TNODatabase
===============================

version number: 0.0.1
author: Kyle Franson, Lynus Zullo

Overview
--------

Python module for interacting with Trans-Neptunian Object Database on DESOPER. Use requires a working DES username & password.

Installation / Usage
--------------------

To install use pip:

    $ pip install TNODatabase


Or clone the repo:

    $ git clone https://github.com/kfranson/TNODatabase.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD