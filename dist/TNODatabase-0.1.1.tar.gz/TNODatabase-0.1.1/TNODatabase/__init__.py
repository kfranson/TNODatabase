from TNODatabase import Connect

__all__ = ['Connect']
